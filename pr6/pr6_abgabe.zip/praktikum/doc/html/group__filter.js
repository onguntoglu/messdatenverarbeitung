var group__filter =
[
    [ "filter.h", "filter_8h.html", null ],
    [ "DEC_RATIO", "group__filter.html#ga328430f9f6c8744c24e39c567ca224ab", null ],
    [ "FILTER_IN_BUF_MASK", "group__filter.html#gaf4ba77aef9a2ffb79f8357e16bb30063", null ],
    [ "FILTER_IN_BUF_POW", "group__filter.html#ga1b8ceacca9c8e49661e247548a598555", null ],
    [ "FILTER_ORD", "group__filter.html#ga5df345259d47edb0bbba3bbe6e5d3c7c", null ],
    [ "decimState_t", "group__filter.html#gaf1016c3d93ceb56ea53f130b53b9312b", [
      [ "ON", "group__filter.html#ggaf1016c3d93ceb56ea53f130b53b9312ba977d478dacaae531f95695750d1e9d03", null ],
      [ "OFF", "group__filter.html#ggaf1016c3d93ceb56ea53f130b53b9312baac132f2982b98bcaa3445e535a03ff75", null ]
    ] ],
    [ "filterFIR", "group__filter.html#ga7d1f92a40ee35909424392a669e417e7", null ],
    [ "filterFIRDecim", "group__filter.html#ga212ad6239ae8a391498d183c391977d7", null ],
    [ "filterIdentity", "group__filter.html#gad3f80b5475f92cf0c0948e98c453e20e", null ],
    [ "filterInit", "group__filter.html#ga678bf02b3f3b0ce7b5a493f21cf31887", null ],
    [ "filterReset", "group__filter.html#gae385f065f3a456bd23f148fa35307f42", null ],
    [ "filterWaitingVals", "group__filter.html#ga8ad96ed7550921af1a5f013bdd2ffc0f", null ],
    [ "filterWrite2Buf", "group__filter.html#ga3a4bcb87932da184a32707b334fb1d33", null ],
    [ "decimation", "group__filter.html#gadb369b223556f4d29c4ff4ed68610eb5", null ]
];