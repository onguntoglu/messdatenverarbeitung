var structfifo =
[
    [ "bytes", "structfifo.html#a8ebcca910572bc803ec5975995ff6cd5", null ],
    [ "data", "structfifo.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "iEnd", "structfifo.html#a3afec6f4801d3a6b1c6f5c9408df4ead", null ],
    [ "iStart", "structfifo.html#a70a5a7d9db96d554744a89a3855d97eb", null ],
    [ "mask", "structfifo.html#a7fd850d4bb04f7410e8e2abf5f349348", null ]
];