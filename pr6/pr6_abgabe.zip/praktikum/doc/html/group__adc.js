var group__adc =
[
    [ "adc.h", "adc_8h.html", null ],
    [ "ADC_OFFSET", "group__adc.html#ga827907ee6183e98bb8a50727540d4bb1", null ],
    [ "trigger_t", "group__adc.html#ga7525d66767406deb7a8b51f927aae2b7", null ],
    [ "trigger", "group__adc.html#gae194cb817eae4085f8023885100c68dd", [
      [ "NONE", "group__adc.html#ggae194cb817eae4085f8023885100c68ddac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "RISING", "group__adc.html#ggae194cb817eae4085f8023885100c68ddad93abe7aced82e9a4fcac4127a36ece3", null ],
      [ "FALLING", "group__adc.html#ggae194cb817eae4085f8023885100c68ddad24712a6a30c1d431b927d1ba2f84b66", null ]
    ] ],
    [ "adcInit", "group__adc.html#ga27c5e947cca4b8e98323253543557b23", null ],
    [ "adcIsRunning", "group__adc.html#ga3e7a7e2c420118e7f3cf5d14ac390b40", null ],
    [ "adcStart", "group__adc.html#gabc524700e7bcb90a38cc9146c5e29aba", null ]
];