var modules =
[
    [ "Analog to Digital Conversion", "group__adc.html", null ],
    [ "Command Interpreter", "group__command.html", null ],
    [ "FIFO-Buffer", "group__fifo.html", null ],
    [ "Digital Filtering", "group__filter.html", null ],
    [ "Serial Port Communication", "group__serial.html", null ]
];