var group__serial =
[
    [ "serial.h", "serial_8h.html", null ],
    [ "BAUD_115200", "group__serial.html#ga662c9e747763825a090529fe88ed9fd5", null ],
    [ "BAUD_19200", "group__serial.html#gacd7a4f8800e9a964e3d402ea3a3beb57", null ],
    [ "BAUD_230400", "group__serial.html#ga52b6ee103e1c7f497a73c6cfc8aed3e6", null ],
    [ "BAUD_56700", "group__serial.html#ga79c260a617901831e49893a960a0426c", null ],
    [ "BAUD_9600", "group__serial.html#gac6f1b052894ecd23fc1b9cdf21325001", null ],
    [ "RX_BUFFER_MASK", "group__serial.html#ga2d550d3221612240ed88b280ca1ac25c", null ],
    [ "RX_BUFFER_POW", "group__serial.html#ga371bd1976f91a80e2af78c0af2acf5fe", null ],
    [ "TX_BUFFER_MASK", "group__serial.html#ga5a7fcc64fc7ca6bea2bca267ff63c029", null ],
    [ "TX_BUFFER_POW", "group__serial.html#gaeca340a2fcdec861f128408ae69a7879", null ],
    [ "bytesInRcvBuf", "group__serial.html#gad50791c6213ca16e924bdfcb5bacc59b", null ],
    [ "serialInit", "group__serial.html#ga937cc2cfada75b0bede2fcb2adcdad2e", null ],
    [ "serialNewLines", "group__serial.html#gad3adb1cb99b174a1a10b8e50a2a95204", null ],
    [ "serialReadByte", "group__serial.html#gacd86b76722d76be6d34ad25d841c5e6b", null ],
    [ "serialReadLine", "group__serial.html#ga9f8b86188769661449d724fbe3560f74", null ],
    [ "serialSendByte", "group__serial.html#ga502d5813f57028a04bb85a92b94302a6", null ],
    [ "serialSendString", "group__serial.html#ga7b2885c2975769ac8d4f09210ee71916", null ],
    [ "serialSendWord", "group__serial.html#ga2bd9bd4fc48a28c6ad53ed90519ccd96", null ]
];