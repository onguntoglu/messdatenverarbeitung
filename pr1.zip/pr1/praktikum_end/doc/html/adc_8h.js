var adc_8h =
[
    [ "ADC_OFFSET", "group__adc.html#ga827907ee6183e98bb8a50727540d4bb1", null ],
    [ "trigger_t", "group__adc.html#ga7525d66767406deb7a8b51f927aae2b7", null ],
    [ "trigger", "group__adc.html#gae194cb817eae4085f8023885100c68dd", null ],
    [ "adcInit", "group__adc.html#ga27c5e947cca4b8e98323253543557b23", null ],
    [ "adcIsRunning", "group__adc.html#ga3e7a7e2c420118e7f3cf5d14ac390b40", null ],
    [ "adcStart", "group__adc.html#gabc524700e7bcb90a38cc9146c5e29aba", null ]
];