var filter__coeff_8h =
[
    [ "FILTER_ORD", "filter__coeff_8h.html#a5df345259d47edb0bbba3bbe6e5d3c7c", null ],
    [ "FIR_COEFF", "filter__coeff_8h.html#a72998788ed13b77fcc5bcf08c50e2039", null ]
];