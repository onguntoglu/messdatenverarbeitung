var serial_8c =
[
    [ "bytesInRcvBuf", "group__serial.html#gad50791c6213ca16e924bdfcb5bacc59b", null ],
    [ "ISR", "serial_8c.html#a1febaffb16c3657348fc3093cd4317ac", null ],
    [ "ISR", "serial_8c.html#abe211e29a2f9eebb063ea3208631be38", null ],
    [ "serialInit", "group__serial.html#ga937cc2cfada75b0bede2fcb2adcdad2e", null ],
    [ "serialNewLines", "group__serial.html#gad3adb1cb99b174a1a10b8e50a2a95204", null ],
    [ "serialReadByte", "group__serial.html#gacd86b76722d76be6d34ad25d841c5e6b", null ],
    [ "serialReadLine", "group__serial.html#ga9f8b86188769661449d724fbe3560f74", null ],
    [ "serialSendByte", "group__serial.html#ga502d5813f57028a04bb85a92b94302a6", null ],
    [ "serialSendString", "group__serial.html#ga7b2885c2975769ac8d4f09210ee71916", null ],
    [ "serialSendWord", "group__serial.html#ga2bd9bd4fc48a28c6ad53ed90519ccd96", null ],
    [ "lines", "serial_8c.html#ae2326351fbde915b2fd75711583fd720", null ],
    [ "rxBuf", "serial_8c.html#a8c05614567de7ee05eca95ca6397f928", null ],
    [ "rxBufMem", "serial_8c.html#a477bb0ba7ce8a341b0312e2158e66c75", null ],
    [ "txBuf", "serial_8c.html#a704c2b3234672c2f38cb5e915ae9632f", null ],
    [ "txBufMem", "serial_8c.html#a401f0b03a6a92dcb4b4ef0c6f317fdac", null ]
];