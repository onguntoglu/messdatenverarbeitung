var files =
[
    [ "adc.c", "adc_8c.html", "adc_8c" ],
    [ "adc.h", "adc_8h.html", "adc_8h" ],
    [ "command.c", "command_8c.html", "command_8c" ],
    [ "command.h", "command_8h.html", "command_8h" ],
    [ "fifo.c", "fifo_8c.html", "fifo_8c" ],
    [ "fifo.h", "fifo_8h.html", "fifo_8h" ],
    [ "filter.c", "filter_8c.html", "filter_8c" ],
    [ "filter.h", "filter_8h.html", "filter_8h" ],
    [ "filter_coeff.h", "filter__coeff_8h.html", "filter__coeff_8h" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "MDV_PR.c", "_m_d_v___p_r_8c.html", "_m_d_v___p_r_8c" ],
    [ "serial.c", "serial_8c.html", "serial_8c" ],
    [ "serial.h", "serial_8h.html", "serial_8h" ]
];