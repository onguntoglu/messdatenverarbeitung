* Um den Code zu bearbeiten, öffnen Sie das Projekt MDV_PR.aps mit dem AVR-Studio
* Im Unterverzeichnis doc befindet sich eine HTML-Dokumentation des Codes. Um Sie anzusehen, öffen Sie die Datei index.html mit einem Browser Ihrer Wahl
* Im Unterverzeichnis matlab befinden sich MATLAB-Skripte zur Arbeit mit dem Sensorknoten. Mit ucAnalogRead.m können Sie Messdaten von dem Sensorknoten nach Matlab einlesen. Die Datei exportKoeff.m erzeugt aus einem Array von Filterkoeffizienten in Maltab einen C-header filter_koeff.h, den Sie in das Projekt MDV_PR einbinden können. 
