#define FILTER_ORD 4
#define FIR_COEFF 1,1,1,1
